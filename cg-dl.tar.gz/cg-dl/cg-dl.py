import os
import re
import argparse
import requests
import subprocess
from datetime import datetime
from bs4 import BeautifulSoup

# 解析命令行参数
parser = argparse.ArgumentParser(description="Download videos from 51cg.fun")
parser.add_argument("urls", nargs="+", help="List of webpage URLs")
parser.add_argument("--output", default=os.path.expanduser("~/Downloads"), help="Path to save the videos (default: Downloads folder)")
args = parser.parse_args()

# 保存路径
save_path = args.output

# 网页列表
webpage_urls = args.urls

# 提取视频地址
def extract_video_urls(source_code):
    pattern = r'"video":\s*{"url":"(.*?)",'
    matches = re.findall(pattern, source_code)
    if not matches:
        pattern = r"<a href=\"(.*?)\""
        matches = re.findall(pattern, source_code)
    
    extracted_urls = []
    for match in matches:
        extracted_url = match.replace(r"\/", "/")
        extracted_urls.append(extracted_url)
    
    return extracted_urls

# 提取视频标题
def extract_title(source_code, index):
    soup = BeautifulSoup(source_code, 'html.parser')
    title_element = soup.find('title')
    if title_element:
        title = title_element.text.strip()
        title = re.sub(r"^(51吃瓜 - )|( - 51cg\.fun)$", "", title)
        if index > 0:
            return f"{title}{index}"
        else:
            return title
    else:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 清理文件名中的非法字符
def sanitize_filename(filename):
    return filename.replace(r"/[\\/:\"*?<>|]/g", "")

# 下载视频
for url in webpage_urls:
    response = requests.get(url)
    if response.status_code == 200:
        source_code = response.text
        video_urls = extract_video_urls(source_code)
        for i, video_url in enumerate(video_urls):
            title = extract_title(source_code, i)
            title = sanitize_filename(title)
            filename = f"{save_path}/{title}.mp4"
            print(f"正在下载第{i+1}个视频: {filename}")
            subprocess.run(["ffmpeg", "-i", video_url, "-c", "copy", filename])
    else:
        print(f"无法提取页面信息: {url}")